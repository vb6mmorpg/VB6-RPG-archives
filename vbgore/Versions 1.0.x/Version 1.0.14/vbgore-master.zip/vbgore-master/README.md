Notice: This project is long dead.

Homepage: http://www.vbgore.com/

vbGORE is a powerful, open source, and free online RPG engine that concentrates on performance and features. With the help of vbGORE's fast networking and powerful graphics engine and some (although not required) knowledge in game programming in Visual Basic 6, you can create the game of your dreams without paying for a ton of bandwidth and a powerful server to support it.

vbGORE is much more powerful than many of your typical Visual Basic made online RPG engine. With the power of the DirectX 8, you are open to all the 3D effects you could want in a 2D RPG engine by putting in 3D rpg engine features from alpha-blending and rotations to scaling and lighting. With 6 tile layers, flexible particle engine and 24 lights per tile, you are able to create a world the way you want it to look. Also, with the optimized binary packet sending and a Winsock API wrapper, you can support tens of thousands of players with less bandwidth than any other VB ORPG engine.
