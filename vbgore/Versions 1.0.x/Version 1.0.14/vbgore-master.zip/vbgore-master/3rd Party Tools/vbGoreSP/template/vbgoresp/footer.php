<?php
$base = '<div class="Foot Apply">
<p>
	<br /><br />
	Coding and Layout &copy; To DarkGrave, Users Online: {online}
</p>
</div>
</body>
</html>';
?>