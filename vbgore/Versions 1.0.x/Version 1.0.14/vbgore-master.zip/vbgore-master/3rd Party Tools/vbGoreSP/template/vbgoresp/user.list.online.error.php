<?php
$base = '<tr>
			<td width="100%">
				<center>{error}</center>
			</td>
		</tr>';
?>