<?php
$base = '<tr>
			<td width="100%" class="button2" style="border-top: 1px solid white;" title="{description}" alt="{description}">
				<a href="{link_vusers}{name}">{name}</a>
			</td>
			<td class="button" style="border-top: 1px solid white;">
				<a href="#">{user_or_gm}</a>
			</td>
		</tr>';
?>