<?php
$base = '<div class="SiteContainer Apply">
<h1>vbGORE <span style="color:limegreen">Profile</span> Error</h1>
	<div class="About">
		<h2>An error has occurred</h2>
		<p>The profile you are trying to reach or get to does not exist please <a href="javascript:history.go(-1)">Go Back</a> and try again!</p>	  
	</div>
	<div id="Form" class="ApplyForm">
    <fieldset>
		<a href="javascript:history.go(-1)">Go Back</a>
	</fieldset>
	</div>
</div>';
?>