<?php
$base = '</table>
		</fieldset>
	</div>
</div>';
?>