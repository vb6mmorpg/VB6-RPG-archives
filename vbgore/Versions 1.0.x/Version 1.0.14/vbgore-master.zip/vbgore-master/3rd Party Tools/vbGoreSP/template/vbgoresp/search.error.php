<?php
$base = '<div class="SiteContainer SignIn">
<h1>vbGORE <span style="color:limegreen">Search</span> Error</h1>
	<div id="Form" class="SignInForm">
		<fieldset>
			<center>{error}</center>
		</fieldset>
	</div>
</div>';
?>