<?php
$base = '<div class="SiteContainer SignIn">
<h1>Vbgore <span style="color:limegreen">User</span> Results</h1>
	<div id="Form" class="SignInForm">
		<fieldset>
			<table width="100%" cellspacing="0">';
?>