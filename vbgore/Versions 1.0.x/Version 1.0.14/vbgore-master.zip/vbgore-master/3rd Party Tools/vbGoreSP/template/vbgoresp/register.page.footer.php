<?php
$base = '</select>
			</li>
			<li>
				<label for="password">Password: </label>
				<input type="password" name="password" size="30" maxlength="30" alt="Password must be 4 to 30 characters long + Alphanumerical" title="Password must be 4 to 30 characters long + Alphanumerical" />
			</li>
			<li>
				<label for="passwordag">Password Again: </label>
				<input type="password" name="passwordag" size="30" maxlength="30"  alt="Password must be 4 to 30 characters long + Alphanumerical" title="Password must be 4 to 30 characters long + Alphanumerical" /> 
			</li>
			<input type="hidden" name="register" value="imregistering">
		</ul>
		<div class="Submit"><input type="submit" value="Register" class="Button" name="submit"></div>
	</form>
	</div>
</fieldset>
</div>';
?>