<?php
$base = '<div class="SiteContainer SignIn">
<h1>vbGORE <span style="color:limegreen">Registration</span> Success</h1>
	<div id="Form" class="SignInForm">
		<fieldset>
			Your account was created.
			<div align="right"><a href="{link_login}">Login</a></div>
		</fieldset>
	</div>
</div>';
?>