<?php
$base = '<div class="SiteContainer SignIn">
<h1>Vbgore <span style="color:limegreen">Registration</span> Error</h1>
<div id="Form" class="SignInForm">
	<fieldset>
        {error_list}
		<br />
		<a href="javascript:history.go(-1)">Go Back</a>
	</fieldset>
	</div>
</div>';
?>