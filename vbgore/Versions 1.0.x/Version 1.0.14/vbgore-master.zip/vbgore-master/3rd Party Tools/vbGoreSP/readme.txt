##################################################
## vbGORE Server Panel [vbGore SP]
## Author: DarkGrave
## Date: 10:15 AM Saturday, June 23, 2007
## Site: http://vbgore.animenetworx.info
##################################################
## Information Page:
## http://www.vbgore.com/vbGORE_SP
##################################################
## Configuration Guide:
## http://www.vbgore.com/vbGORE_SP_Configuration
##################################################
## Changelog:
## http://www.vbgore.com/vbGORE_SP_Changelog
##################################################
##
## Enjoy The Release - vbGORE SP Team