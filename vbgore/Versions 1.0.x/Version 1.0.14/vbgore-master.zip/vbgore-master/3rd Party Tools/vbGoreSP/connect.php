<?php
/*
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------
 vbGORE Server Panel [vbGORE SP]
 @Author: DarkGrave
 @Date: 9:39 PM Tuesday, June 26, 2007
 @Version: 2.0.1 [Excentric]
 @Copyright: Creative Commons Attribution-Noncommercial-Share Alike 3.0 License
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------
 [You must leave this comment intact at all times]
   * This work is licensed under the Creative Commons Attribution-Noncommercial-Share Alike 3.0 License.
   * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to:
   * Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
if(!defined('IN_VBGORESP')){
	exit;
}

$dbsettings = Array(
        "server"        => "localhost",			// MySQL server name. (Default: localhost)
        "user"          => "MySql_root",		// MySQL username. (Usually "root")
        "pass"          => "MySql_pass",		// MySQL password.
        "name"          => "MySql_DBName",		// MySQL database name. (Usually "vbgore")
        "port"			=> "false");			// MySQL Port. (Usually 'false' change if necessary)
?>