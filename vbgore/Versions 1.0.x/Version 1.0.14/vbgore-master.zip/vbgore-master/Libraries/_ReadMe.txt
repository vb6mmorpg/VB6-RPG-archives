This file only applies to those who still have files in this directory (installation went wrong)!






Copy these files to your system directory if you are recieving errors about files not found
that end with ".OCX" or ".DLL" and this should solve the problem.

System Folder Paths:

95/98/ME Users:
C:\Windows\System\

2000/XP Users:
C:\Windows\System32\

Unsure what you have? If you have a System32 folder, then that is probably the one you want to use. :)
