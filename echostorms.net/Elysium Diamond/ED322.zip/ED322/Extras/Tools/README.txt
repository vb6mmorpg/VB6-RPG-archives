This folder contains files from the Elysium members. Most of them are not from Elysium and
are to be used at your own risk. Don't worry, I wouldn't have put them here if I knew they
could harm you ... but still, just in case. They might come in handy!