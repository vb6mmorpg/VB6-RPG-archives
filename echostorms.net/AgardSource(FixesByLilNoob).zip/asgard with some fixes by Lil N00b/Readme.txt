    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA



Well, here it is, the source code to my Asgard Engine... Although it may not look
too special yet, many hours of work went into this code and many more will follow.

The biggest change is that now others can help with it. I hope they will.

If you decide not to help but make your own engine with it, I can't stop you nor do
I want to. But if you want to help me improve it, do that.

At the time of writing, the websites you can go to to get support with this code are:

	- www.elysiumsource.com
	- www.asgard-engine.net.ms

If you want to know more or have any questions or feedback, contact me on either
of this sites or via mail at atlantisbase@gmail.com

And now... Have fun!



Greetz, Atlantis